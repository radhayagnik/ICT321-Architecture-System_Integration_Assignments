//Code self-contained by 
//Author : Radha Yagnik

from bottle import route, run, template, static_file, url, default_app, request, get, post, delete, debug
import bottle
import json
import os
import sys
from xml.dom import minidom, Node
import xml.etree.ElementTree as ET


@route('/')
def index():
    """Home Page"""
    return template("plan_journey_map.html", message="hello")

@route('/get_Journey/<journeyName>')
def get_Journey(journeyName="noFile"):
    """Retrieve Journey"""
    try:
        filename="xml/"+journeyName+".xml"
        DOMTree = minidom.parse(filename)
        journeys=DOMTree.documentElement
        result=[]
        journey=journeys.getElementsByTagName("journey")
        jleg=journeys.getElementsByTagName("journeyleg")
        for j in jleg:
            cnt=1
            pos=j.getElementsByTagName("pos")[0]
            #print("pos:%s" %pos.childNodes[0].data)
            result.append("pos:"+pos.childNodes[0].data)
            let=j.getElementsByTagName("latlng")[0]
            #print("latlng:%s" %let.childNodes[0].data)
            result.append("latlng:"+let.childNodes[0].data)
            cnt= int(cnt)+1
        result1= json.dumps(result)    
        return result1
    except:        
        return "File Not Found"
    
@route('/saveJourney/<journeyInfo>')
def saveJourney(journeyInfo="noInfo"):
    """Saves Journey"""
    return journeyInfo

@route('/saveJourney', method='POST')
def saveJourney():
    """Saves Journey"""
    journey = request.forms.get('journey')
    xml = request.forms.get('journey')
    filename="xml/"+journey+".xml"
    myfile = open(filename, "W")
    result=myfile.write(xml)
    return journey

debug(True)
application = default_app()
if __name__ == '__main__':
    bottle.debug(True)
    bottle.run(host='localhost', port=8080)

    
